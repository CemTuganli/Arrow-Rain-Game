﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class Arrows : IDisposable
    {
        static readonly Controller ctrl = Controller.Ctrl;
        static readonly Globals _glo = Globals.LockObject;
        static readonly FireBullets _fb = FireBullets.Fire;
        static readonly Stats _st = Stats.St;
        static readonly DrawMap _dm = DrawMap.Dm;

        #region Singleton
        private static Lazy<Arrows> _arr;
        public static Arrows Arr
        {
            get
            {
                if (_arr == null)
                     _arr = new Lazy<Arrows>(() => new Arrows());
                return _arr.Value;
            }
        }
        private Arrows()
        {

        }
        #endregion

        public byte _apx1 = 0;
        public byte _apy1 = 0;
        public byte _apx2 = 0;
        public byte _apy2 = 0;

        public byte _apx3 = 0;
        public byte _apy3 = 0;

        public byte _apx4 = 0;
        public byte _apy4 = 0;

        public byte _apx5 = 0;
        public byte _apy5 = 0;

        public readonly Random rnd = new Random();

        public void CreateArrows()
        {
            _apx1 = Convert.ToByte(rnd.Next(30, 35));
            _apy1 = Convert.ToByte(rnd.Next(3, 5));

            _apx2 = Convert.ToByte(rnd.Next(36, 40));
            _apy2 = Convert.ToByte(rnd.Next(3, 5));

            _apx3 = Convert.ToByte(rnd.Next(41, 45));
            _apy3 = Convert.ToByte(rnd.Next(3, 5));

            _apx4 = Convert.ToByte(rnd.Next(46, 50));
            _apy4 = Convert.ToByte(rnd.Next(3, 5));

            _apx5 = Convert.ToByte(rnd.Next(51, 55));
            _apy5 = Convert.ToByte(rnd.Next(3, 5));

        }

        public async Task MoveDrawArrow1()
        {
            Console.CursorVisible = false;

            while (true)
            {
                if (ctrl.C % 2 == 0)
                {
                    if (_fb.arrow1bodypartAmount == 3)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx1, _apy1 + 1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx1, _apy1 + 2);
                            Console.Write('v');
                        }

                        await Task.Delay(150);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx1, _apy1 + 1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx1, _apy1 + 2);
                            Console.Write(' ');
                            if (_apy1 + 2 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx1 = Convert.ToByte(rnd.Next(30, 35));
                                    _apy1 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow1bodypartAmount = 3;

                                }

                            }
                            else
                            {
                                ++_apy1;
                            }
                        }
                        if (_dm.PPx == Arr._apx1 && _dm.PPy == Arr._apy1 + 2)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning); 
                            }
                        }
                    }
                    else if (_fb.arrow1bodypartAmount == 2)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx1, _apy1 + 1);
                            Console.Write('|');
                        }

                        await Task.Delay(170);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx1, _apy1 + 1);
                            Console.Write(' ');
                            if (_apy1 + 1 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx1 = Convert.ToByte(rnd.Next(30, 35));
                                    _apy1 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow1bodypartAmount = 3;

                                }

                            }
                            else
                            {
                                ++_apy1;
                            }
                        }
                        if (_dm.PPx == Arr._apx1 && _dm.PPy == Arr._apy1 + 1)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }
                        }
                    }
                    else if (_fb.arrow1bodypartAmount == 1)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write('|');
                        }

                        await Task.Delay(170);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx1, _apy1);
                            Console.Write(' ');
                            if (_apy1 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx1 = Convert.ToByte(rnd.Next(30, 35));
                                    _apy1 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow1bodypartAmount = 3;


                                }

                            }
                            else
                            {
                                ++_apy1;
                            }
                        }

                        if (_dm.PPx == Arr._apx1 && _dm.PPy == Arr._apy1)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }
                        }
                    }

                    Gallons.RefreshGallonsForArrow1();
                }
            }
        }

        public async Task MoveDrawArrow2()
        {
            Console.CursorVisible = false;

            while (true)
            {
                if (ctrl.C % 2 == 0)
                {
                    if (_fb.arrow2bodypartAmount == 3)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx2, _apy2 + 1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx2, _apy2 + 2);
                            Console.Write('v');

                        }

                        await Task.Delay(220);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx2, _apy2 + 1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx2, _apy2 + 2);
                            Console.Write(' ');
                            if (_apy2 + 2 == 24)
                            {
                                _apx2 = Convert.ToByte(rnd.Next(36, 40));
                                _apy2 = Convert.ToByte(rnd.Next(3, 5));
                                _fb.arrow2bodypartAmount = 3;

                            }
                            else
                            {
                                ++_apy2;
                            }
                        }

                        if (_dm.PPx == Arr._apx2 && _dm.PPy == Arr._apy2 + 2)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning); 
                            }

                        }
                    }
                    else if (_fb.arrow2bodypartAmount == 2)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx2, _apy2 + 1);
                            Console.Write('|');
                        }

                        await Task.Delay(220);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx2, _apy2 + 1);
                            Console.Write(' ');
                            if (_apy2 + 1 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx2 = Convert.ToByte(rnd.Next(36, 40));
                                    _apy2 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow2bodypartAmount = 3;
                                    


                                }

                            }
                            else
                            {
                                ++_apy2;
                            }
                        }
                        if (_dm.PPx == Arr._apx2 && _dm.PPy == Arr._apy2 + 1)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }

                        }
                    }
                    else if (_fb.arrow2bodypartAmount == 1)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write('|');
                        }

                        await Task.Delay(220);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx2, _apy2);
                            Console.Write(' ');
                            if (_apy2 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx2 = Convert.ToByte(rnd.Next(36, 40));
                                    _apy2 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow2bodypartAmount = 3;


                                }

                            }
                            else
                            {
                                ++_apy2;
                            }
                        }
                        if (_dm.PPx == Arr._apx2 && _dm.PPy == Arr._apy2)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }

                        }
                    }
                    
                    Gallons.RefreshGallonsForArrow2();
                }

            }

        }

        public async Task MoveDrawArrow3()
        {
            Console.CursorVisible = false;
            while (true)
            {
                if (ctrl.C % 2 == 0)
                {
                    if (_fb.arrow3bodypartAmount == 3)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx3, _apy3 + 1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx3, _apy3 + 2);
                            Console.Write('v');
                        }

                        await Task.Delay(270);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx3, _apy3 + 1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx3, _apy3 + 2);
                            Console.Write(' ');
                            if (_apy3 + 2 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx3 = Convert.ToByte(rnd.Next(41, 45));
                                    _apy3 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow3bodypartAmount = 3;

                                }

                            }
                            else
                            {
                                ++_apy3;
                            }
                        }
                        if (_dm.PPx == Arr._apx3 && _dm.PPy == Arr._apy3 + 2)
                        {
                            --_st.Health;
                            _st.DrawUpdateStats();
                            _ = Task.Run(TwinkleHealthWarning);

                        }
                    }
                    else if (_fb.arrow3bodypartAmount == 2)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx3, _apy3 + 1);
                            Console.Write('|');
                        }

                        await Task.Delay(270);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx3, _apy3 + 1);
                            Console.Write(' ');
                            if (_apy3 + 1 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx3 = Convert.ToByte(rnd.Next(41, 45));
                                    _apy3 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow3bodypartAmount = 3;

                                }

                            }
                            else
                            {
                                ++_apy3;
                            }
                        }
                        if (_dm.PPx == Arr._apx3 && _dm.PPy == Arr._apy3 + 1)
                        {
                            --_st.Health;
                            _st.DrawUpdateStats();
                            _ = Task.Run(TwinkleHealthWarning);

                        }
                    }
                    else if (_fb.arrow3bodypartAmount == 1)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write('|');
                        }

                        await Task.Delay(270);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx3, _apy3);
                            Console.Write(' ');
                            if (_apy3 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx3 = Convert.ToByte(rnd.Next(41, 45));
                                    _apy3 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow3bodypartAmount = 3;

                                }

                            }
                            else
                            {
                                ++_apy3;
                            }
                        }
                        if (_dm.PPx == Arr._apx3 && _dm.PPy == Arr._apy3)
                        {
                            --_st.Health;
                            _st.DrawUpdateStats();
                            _ = Task.Run(TwinkleHealthWarning);

                        }
                    }
                }

                Gallons.RefreshGallonsForArrow3();
            }
        }
        public async Task MoveDrawArrow4()
        {
            Console.CursorVisible = false;

            while (true)
            {
                if (ctrl.C % 2 == 0)
                {
                    if (_fb.arrow4bodypartAmount == 3)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx4, _apy4 + 1);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx4, _apy4 + 2);
                            Console.Write('v');
                        }

                        await Task.Delay(320);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx4, _apy4 + 1);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx4, _apy4 + 2);
                            Console.Write(' ');
                            if (_apy4 + 2 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx4 = Convert.ToByte(rnd.Next(46, 50));
                                    _apy4 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow4bodypartAmount = 3;
                                }

                            }
                            else
                            {
                                ++_apy4;
                            }
                        }
                        if (_dm.PPx == Arr._apx4 && _dm.PPy == Arr._apy4 + 2)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }
                        }
                    }
                    else if (_fb.arrow4bodypartAmount == 2)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write('|');
                            Console.SetCursorPosition(_apx4, _apy4 + 1);
                            Console.Write('|');
                        }

                        await Task.Delay(320);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write(' ');
                            Console.SetCursorPosition(_apx4, _apy4 + 1);
                            Console.Write(' ');
                            if (_apy4 + 1 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx4 = Convert.ToByte(rnd.Next(46, 50));
                                    _apy4 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow4bodypartAmount = 3;
                                }

                            }
                            else
                            {
                                ++_apy4;
                            }
                        }
                        if (_dm.PPx == Arr._apx4 && _dm.PPy == Arr._apy4 + 1)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }
                        }
                    }
                    else if (_fb.arrow4bodypartAmount == 1)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write('|');
                        }

                        await Task.Delay(320);

                        lock (_glo)
                        {
                            Console.SetCursorPosition(_apx4, _apy4);
                            Console.Write(' ');
                            if (_apy4 == 24)
                            {
                                lock (_glo)
                                {
                                    _apx4 = Convert.ToByte(rnd.Next(46, 50));
                                    _apy4 = Convert.ToByte(rnd.Next(3, 5));
                                    _fb.arrow4bodypartAmount = 3;
                                }

                            }
                            else
                            {
                                ++_apy4;
                            }
                        }
                        if (_dm.PPx == Arr._apx4 && _dm.PPy == Arr._apy4)
                        {
                            lock (_glo)
                            {
                                --_st.Health;
                                _st.DrawUpdateStats();
                                _ = Task.Run(TwinkleHealthWarning);
                            }
                        }
                    }

                    
                    Gallons.RefreshGallonsForArrow4();
                }
            }
        }
        public async Task TwinkleHealthWarning()
        {
            if (_st.Health < 5)
            {
                lock (_glo)
                {
                    Console.SetCursorPosition(_dm.PPx, _dm.PPy);
                    Console.Write('0');
                }

                string message = "You've Taken Damage!";

                Console.Beep();

                byte i = 0;
                while (i < 7)
                {
                    if (ctrl.C % 2 == 0)
                    {
                        lock (_glo)
                        {
                            Console.SetCursorPosition(55, 3);
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.Write(message);
                        }

                        await Task.Delay(125);

                        lock (_glo)
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.SetCursorPosition(55, 3);
                            Console.Write(message);
                            i++;
                        }
                        await Task.Delay(125);
                        lock (_glo)
                        {
                            Console.ForegroundColor = ConsoleColor.White;
                            string space = new string(' ', message.Length);
                            Console.SetCursorPosition(55, 3);
                            Console.Write(space);
                        }
                        Console.SetCursorPosition(_dm.PPx, _dm.PPy);
                        Console.Write('0');
                    }

                } 
            }
            
        }

        public void Dispose()
        {
        }
    }
}
