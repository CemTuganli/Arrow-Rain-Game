﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class Globals : IDisposable
    {
        private static Lazy<Globals> _lockObject;
        public static Globals LockObject
        {
            get 
            { 
                if (_lockObject == null)
                {
                    _lockObject = new Lazy<Globals>(() => new Globals());
                } 
                return _lockObject.Value;
            }
        }

        private Globals() { }

        public void Dispose()
        {
        }
    }
}
