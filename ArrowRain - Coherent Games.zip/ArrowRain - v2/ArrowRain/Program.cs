﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class Program : IDisposable
    {
        static readonly DrawMap _dm = DrawMap.Dm;
        static readonly Controller _ctrl = Controller.Ctrl;
        static readonly Arrows _arr = Arrows.Arr;
        static readonly FireBullets _fire = FireBullets.Fire;
        static readonly Stats _st = Stats.St;
        static readonly Globals _globalLock = Globals.LockObject;

        #region SINGLETON
        private static Lazy<Program> _pr;
        public static Program Pr
        {
            get
            {
                if (_pr == null)
                {
                    _pr = new Lazy<Program>(() => new Program());
                }
                return _pr.Value;
            }
        }

        #endregion

        private static readonly byte level = 1;
        public byte x1, y1;

        public string fileName = "ArrowRainTXT.txt";

        public bool okay = false;

        public int i = 0;
        public int index = 0;
        public byte height;
        byte x;
        string newData;

        public List<string> lines = new List<string>();

        static async Task Main(string[] args)
        {
            Console.SetBufferSize(500, 500);
            Console.CursorVisible = true;
            if (level == 1)
            {
                await Pr.Opening(Pr.x1, Pr.y1);

            }
            else if (level == 2)
            {
                _dm.DrawPlayer();
                _dm.DrawGameMap();
                _dm.DrawGround();
                _fire.ShowRemainingBullets();

                _ = Task.Run(ManageControllerTask);
                await Task.Run(ManageArrowsLevel1);
            }
        }

        public static async Task ManageArrowsLevel1()
        {
            _arr.CreateArrows();
            _ = Task.Run(_arr.MoveDrawArrow1);
            _ = Task.Run(_arr.MoveDrawArrow2);
            _ = Task.Run(_arr.MoveDrawArrow3);
            await Task.Run(_arr.MoveDrawArrow4);
        }

        public static void ManageControllerTask()
        {
            while (true)
            {
                _ = _ctrl.ManageController();
            }
        }

        public async Task Opening(byte x, byte y)
        {
            Header(out x1, out y1);
            Console.ForegroundColor = ConsoleColor.Gray;
            while (true)
            {
                Pr.LoginPlayer();
                if (Pr.okay == true)
                {
                    Console.CursorVisible = false;
                    await Pr.Options(x1, y1);
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (ConsoleKey.D1 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        _ctrl.C = 0;

                        _dm.DrawPlayer();
                        _dm.DrawGameMap();
                        _dm.DrawGround();
                        Gallons.CreateDrawGallons();
                        _st.DrawUpdateStats();
                        _fire.ShowRemainingBullets();

                        _ = Task.Run(ManageControllerTask);
                        await Task.Run(ManageArrowsLevel1);
                    }
                    else if (ConsoleKey.D2 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowControllers();

                    }
                    else if (ConsoleKey.D3 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowIstatistics(x1, y1);
                    }
                    break;
                }
            }
        }

        private void Header(out byte x1, out byte y1)
        {
            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                string message1 = "Welcome To ARROW RAIN!";
                string message2 = "by Coherent Games";

                byte width = Convert.ToByte(Console.WindowWidth);
                byte height = Convert.ToByte(Console.WindowHeight);
                x1 = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(message1.Length)) / 2));
                y1 = Convert.ToByte(Convert.ToByte(height) / 2);
                Console.SetCursorPosition(x1 - 1, y1 - 4);
                Console.WriteLine(message1);
                Console.SetCursorPosition(x1 + 1, y1 - 2);
                Console.WriteLine(message2);
                Console.ForegroundColor = ConsoleColor.White;

            }
        }

        public List<string> data;
        bool doit = true;
        public async Task ShowIstatistics(byte x1, byte y1)
        {
            Console.SetCursorPosition(70, 2);
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("Go to Main Menu: B");
            Console.ForegroundColor = ConsoleColor.White;

            string messageStatistics = "STATISTICS";
            byte width = Convert.ToByte(Console.WindowWidth);
            height = 1;
            x = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(messageStatistics.Length)) / 2));
            Console.SetCursorPosition(x - 1, height);
            Console.WriteLine(messageStatistics);

            data = new List<string>();

            string filepath = Path.GetFullPath(fileName);
            using (StreamReader sr = new StreamReader(filepath))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    data.Add(line);
                }

                sr.Close();
            }

            if (doit)
            {
                newData = Pr.playerName + " - Name, " + _st.Score + " - Score, " + _st.ArrowsDestroyed + " - Arrows Destroyed, " + _st.resultTimePassed + " - TimePlayed";

                data.Add(newData);
                doit = false;
            }

            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach (string item in data)
                {
                    writer.WriteLine(item);
                }
                writer.Close();
            }

            foreach (string item in data)
            {
                Console.SetCursorPosition(1, ++height + 2);
                Console.Write(item);
            }

        menu:
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                await Pr.Options(x1, y1);

            }
            else
            {
                goto menu;
            }

        }


        public string enternamemessage = "Enter player name: ";
        public string playerName;
        public int PlayerID;

        public void LoginPlayer()
        {

            Console.SetCursorPosition(0, 15);
            Console.Write(Pr.enternamemessage);

            Pr.playerName = Console.ReadLine();


            // Check if the player name is empty or null
            if (string.IsNullOrWhiteSpace(Pr.playerName))
            {
                WriteEraseCanNOTbeEmptyMessage();
            }

            // Check if the player name is too long
            if (Pr.playerName.Length > 50)
            {
                WriteErase50CharactersMessage();
            }

            string filepath = Path.GetFullPath(fileName);

            StreamReader reader = new StreamReader(filepath);
            string line;
            List<string> words = new List<string>();
            while ((line = reader.ReadLine()) != null)
            {

                string[] wordArray = line.Split(' ');

                foreach (string word in wordArray)
                {
                    words.Add(word);
                }
            }

            reader.Close();

            bool sameName = false;
            foreach (string item in words)
            {
                if (Pr.playerName == item)
                {
                    sameName = true;
                    break;
                }
            }

            // Take appropriate action based on the result of the search
            if (sameName)
            {
                WriteEraseAlreadyExistsMessage();
            }
            else
            {

                PlayerAddedMessageWriteErase();
                Pr.okay = true;
            }

        }
        public void PlayerAddedMessageWriteErase()
        {
            string playeraddedMessage = "Player added.";
            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(playeraddedMessage);
            }
            Task.Delay(2000).Wait();
            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', playeraddedMessage.Length);
                Console.Write(space);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }

        public void WriteEraseCanNOTbeEmptyMessage()
        {
            string messageCanNotBeEmpty = "Player name cannot be empty.";

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.Write(messageCanNotBeEmpty);
            }

            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', messageCanNotBeEmpty.Length);
                Console.Write(space);
                Console.ForegroundColor = ConsoleColor.White;

            }


        }

        public void WriteErase50CharactersMessage()
        {


            string message50Characters = "Player name is too long. Maximum length is 50 characters.";

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.WriteLine(message50Characters);
            }

            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', message50Characters.Length);
                Console.Write(space);

                Console.SetCursorPosition(Pr.enternamemessage.Length, 15);
                string spaceName = new string(' ', Pr.playerName.Length);
                Console.Write(spaceName);
            }


        }

        public void WriteEraseAlreadyExistsMessage()
        {
            Program pr = new Program();

            string messageAlreadyExists = "Player name already exists. Use Another Name!";
            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.WriteLine(messageAlreadyExists);
            }
            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', messageAlreadyExists.Length);
                Console.Write(space);
            }

            Console.SetCursorPosition(pr.enternamemessage.Length, 15);
            string spaceName = new string(' ', pr.enternamemessage.Length);
            Console.Write(spaceName);
        }

        bool DoAfterOptions = true;
        public async Task Options(byte x, byte y)
        {
            Header(out x, out y);

            string message3 = "PRESS";
            string message4 = "1 - Start ARROW RAIN!";
            string message5 = "2 - Controlls";
            string message6 = "3 - Statistics";

            lock (_globalLock)
            {
                Console.SetCursorPosition(x + 1, y);
                Console.WriteLine(message3);
                Console.SetCursorPosition(x + 1, y + 1);
                Console.WriteLine(message4);
                Console.SetCursorPosition(x + 1, y + 2);
                Console.WriteLine(message5);
                Console.SetCursorPosition(x + 1, y + 3);
                Console.WriteLine(message6);
            }

            while (true)
            {
                if (Pr.okay == true)
                {
                    Console.CursorVisible = false;
                menu:
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (ConsoleKey.D1 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        _ctrl.C = 0;

                        _dm.DrawPlayer();
                        _dm.DrawGameMap();
                        _dm.DrawGround();
                        Gallons.CreateDrawGallons();
                        _st.DrawUpdateStats();
                        _fire.ShowRemainingBullets();


                        _ = Task.Run(ManageControllerTask);
                        await Task.Run(ManageArrowsLevel1);

                    }
                    else if (ConsoleKey.D2 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();
                        await ShowControllers();


                    }
                    else if (ConsoleKey.D3 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowIstatistics(x1, y1);
                    }
                    else
                    {
                        goto menu;
                    }
                    break;
                }
            }
        }

        public async Task ShowControllers()
        {
            string messageStatistics = "CONTROLLERS";
            byte width = Convert.ToByte(Console.WindowWidth);
            height = 1;
            x = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(messageStatistics.Length)) / 2));
            Console.SetCursorPosition(x - 1, height);
            Console.WriteLine(messageStatistics);

            Console.SetCursorPosition(70, 2);
            Console.WriteLine("Go to Main Menu: B");

            Console.WriteLine("Press 'A' to Move Left \n");
            Console.WriteLine("Press 'D' to Move Right \n");
            Console.WriteLine("Press 'F' to Fire \n");
            Console.WriteLine("Press 'P' to Pause Game \n");

        menu:
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                await Pr.Options(x1, y1);

            }
            else
            {
                goto menu;
            }
        }

        public void Dispose()
        {

        }
    }
}
