﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class Controller:IDisposable
    {
        static readonly MovePlayer _mp = MovePlayer.Mp;
        static readonly FireBullets _fb = FireBullets.Fire;

        #region Singleton
        private static Lazy<Controller> _ctrl;
        public static Controller Ctrl
        {
            get
            {
                if (_ctrl == null)
                {
                    _ctrl = new Lazy<Controller>(() => new Controller());
                }
                return _ctrl.Value;
            }
        }

        


        private Controller() { }
        #endregion

        private byte _c = 0;
        public byte C
        {
            get { return _c; }
            set { _c = value; }
        }

        public bool restart = false;
        public async Task ManageController()
        {
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (ConsoleKey.D == key.Key)
            {
                _mp.MovePlayerRight();
            }
            else if (ConsoleKey.A == key.Key)
            {
                _mp.MovePlayerLeft();
            }
            else if (ConsoleKey.F == key.Key && _fb.NotEnoughAmmoMessage == "")
            {
                await Task.Run(_fb.FireMoveBullets);
            }
            else if (ConsoleKey.P == key.Key)
            {
                if (_c == 255)
                {
                     _c = 255;
                }
                else
                {
                    ++_c;
                }
            }
            else if (ConsoleKey.R == key.Key)
            {
                restart = true;

                //_fb.bulletXCoord = 0;
                //_fb.bulletYCoord = 0;
                //Console.SetCursorPosition(_fb.bulletXCoord, _fb.bulletYCoord);
                //Console.Write(' ');

                //restart = false;

            }
            
        }
        
        public void Dispose()
        {
        }
    }
   
}
