﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Reflection;

namespace ArrowRain
{
    public class Stats : IDisposable
    {
        static readonly Globals _glo = Globals.LockObject;
        static readonly Controller _ctrl = Controller.Ctrl;
        static readonly DrawMap _dm = DrawMap.Dm;
        static readonly Program _pr = Program.Pr;

        public int resultTimePassed = 0;

        #region Singleton
        private static Lazy<Stats> _st;
        public static Stats St
        {
            get
            {
                if (_st == null)
                {
                    _st = new Lazy<Stats>(() => new Stats());
                }
                return _st.Value;

            }
        }
        public Stats()
        { }
        #endregion


        private byte _health = 5;
        public byte Health
        {
            get { return _health; }
            set { _health = value; }
        }

        private byte _score = 0;
        public byte Score
        {
            get { return _score; }
            set { _score = value; }
        }

        private byte _arrowsdestroyed = 0;
        public byte ArrowsDestroyed
        {
            get { return _arrowsdestroyed; }
            set { _arrowsdestroyed = value; }
        }

        public byte count = 0;
        public void DrawUpdateStats()
        {
            Console.SetCursorPosition(55, 2);
            Console.Write("Health: " + _health + "  Score: " + _score + "  Arrows Destroyed: " + _arrowsdestroyed);

            lock (_glo)
            {
                int resultTimePassed = 0;

                if (_health <= 0 || _health > 240)
                {
                    Console.Beep();
                    _health = 0;
                    _ctrl.C = 255;


                    _dm.counterstop = true;
                    resultTimePassed = _dm.counter;


                    Console.SetCursorPosition(28, 0);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("GAME OVER !!!");
                    Console.ForegroundColor = ConsoleColor.White;


                    string newData = _pr.playerName.ToString() + " - Name, " + Score.ToString() + " - Score, " + ArrowsDestroyed + " - Arrows Destroyed, " + resultTimePassed + " - Gameplay Time";

                    _pr.data.RemoveAt(_pr.data.Count - 1);
                    _pr.data.Add(newData);

                    using (StreamWriter writer = new StreamWriter(_pr.fileName))
                    {
                        foreach (string item in _pr.data)
                        {
                            writer.WriteLine(item);
                        }
                        writer.Close();
                    }

                    //foreach (string item in _pr.data)
                    //{
                    //    Console.SetCursorPosition(1, ++_pr.height + 2);
                    //    Console.Write(item);
                    //}

                    GoBack2();
                 
                }

            }
        }

        private void GoBack2()
        {
            Console.SetCursorPosition(70, 4);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Go to Main Menu: B");
            Console.ForegroundColor = ConsoleColor.White;

        menu:
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                _health = 5;
                _score = 0;
                _arrowsdestroyed = 0;
                _ctrl.C = 255;
                _ = _pr.Options(_pr.x1, _pr.y1);

            }
            else
            {
                goto menu;
            }
        }

        public void Dispose()
        {
        }
    }
}
