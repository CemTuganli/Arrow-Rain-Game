Thank you for downloading this game!!!

How To Play:

Press 'A' key to move Left
Press 'D' key to move Right
Press 'F' key to shoot Bullets

Avoid Arrows coming towards you!
Hit Gallons and Arrows to earn points!

Enjoy the Game!

ArrowRain is a 2D ASCII Console Game created & developed by Coherent Games which is owned by solo game developer by Cem Tuğanlı

Date: 04/26/2023