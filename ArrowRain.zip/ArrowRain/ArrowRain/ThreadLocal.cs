﻿using System;

namespace ArrowRain
{
    internal class ThreadLocal
    {
        private Func<Random> value;

        public ThreadLocal(Func<Random> value)
        {
            this.value = value;
        }
    }
}