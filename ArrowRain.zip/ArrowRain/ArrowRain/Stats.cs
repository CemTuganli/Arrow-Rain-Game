﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ArrowRain
{
    public class Stats : IDisposable
    {
        static readonly Globals _glo = Globals.LockObject;
        static readonly Controller _ctrl = Controller.Ctrl;
        static readonly DrawMap _dm = DrawMap.Dm;
        static readonly Program _pr = Program.Pr;


        #region Singleton
        private static Lazy<Stats> _st;
        public static Stats St
        {
            get
            {
                if (_st == null)
                {
                    _st = new Lazy<Stats>(() => new Stats());
                }
                return _st.Value;

            }
        }
        public Stats()
        { }
        #endregion


        private byte _health = 5;
        public byte Health
        {
            get { return _health; }
            set { _health = value; }
        }

        private byte _score = 0;
        public byte Score
        {
            get { return _score; }
            set { _score = value; }
        }

        private byte _arrowsdestroyed = 0;
        public byte ArrowsDestroyed
        {
            get { return _arrowsdestroyed; }
            set { _arrowsdestroyed = value; }
        }

        public byte count = 0;
        public void DrawUpdateStats()
        {
            string connectionString = "Data Source=.;Initial Catalog=ArrowRainDB;Integrated Security=True;";

            Console.SetCursorPosition(55, 2);
            Console.Write("Health: " + _health + "  Score: " + _score + "  Arrows Destroyed: " + _arrowsdestroyed);

            lock (_glo)
            {
                int resultTimePassed = 0;

                if (_health <= 0 || _health > 240)
                {
                    Console.Beep();
                    _health = 0;
                    _ctrl.C = 255;


                    _dm.counterstop = true;
                    resultTimePassed = _dm.counter;


                    Console.SetCursorPosition(28, 0);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("GAME OVER !!!");
                    Console.ForegroundColor = ConsoleColor.White;


                    try
                    {
                        // Set up a connection to the database
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            // Check if the connection to the database can be opened
                            if (connection.State == ConnectionState.Closed)
                            {
                                connection.Open();
                            }

                            // Set up a command to execute against the database
                            using (SqlCommand command = new SqlCommand())
                            {
                                command.Connection = connection;

                                // Insert new player into database
                                command.CommandText = "UPDATE PlayerLogin SET Score = @Score, ArrowsDestroyed = @ArrowsDestroyed, TimePlayedInSeconds = @TimePlayedInSeconds where PlayerID = @PlayerID";
                                command.Parameters.AddWithValue("@PlayerID", _pr.PlayerID);
                                command.Parameters.AddWithValue("@Score", _score);
                                command.Parameters.AddWithValue("@ArrowsDestroyed", _arrowsdestroyed);
                                command.Parameters.AddWithValue("@TimePlayedInSeconds", resultTimePassed);

                                int rowsaffected = command.ExecuteNonQuery();
                                //if (rowsaffected > 0)
                                //{
                                //    Console.Write("SUCCESFUL !!!");
                                //}
                                //else
                                //{
                                //    Console.Write("FAILURE !!!");
                                //}

                                connection.Close();
                            }

                        }
                    }
                    catch (SqlException ex)
                    {
                        // Display an error message to the user
                        Console.WriteLine(ex.Message);
                    }


                    GoBack2();

                }
                
            }
        }

        private void GoBack2()
        {
            Console.SetCursorPosition(70, 4);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Go to Main Menu: B");
            Console.ForegroundColor = ConsoleColor.White;

        menu:
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                _health = 5;
                _score = 0;
                _arrowsdestroyed = 0;
                _ctrl.C = 255;
                _ = _pr.Options(_pr.x1, _pr.y1);

            }
            else
            {
                goto menu;
            }
        }

        public void Dispose()
        {
        }
    }
}
