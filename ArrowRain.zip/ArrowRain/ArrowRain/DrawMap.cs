﻿using System;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class DrawMap : IDisposable
    {
        #region Singleton
        private static Lazy<DrawMap> _dm;
        public static DrawMap Dm
        {
            get
            {
                if (_dm == null)
                {
                    _dm = new Lazy<DrawMap>(() => new DrawMap());
                }
                return _dm.Value;
            }
        }

        public DrawMap()
        {

        }
        #endregion

        public byte PPx = 28;
        public byte PPy = 24;
        public void DrawGameMap()
        {
            Console.ForegroundColor = ConsoleColor.DarkYellow;
            for (int j = 0; j < 27; j++)
            {
                Console.SetCursorPosition(25, 1 + j);
                for (int i = 0; i < 29; i++)
                {
                    if (j < 2)
                    {
                        Console.Write('#');
                    }
                    else if (i < 3)
                    {
                        Console.Write('#');
                    }
                    else if (i > 25)
                    {
                        Console.SetCursorPosition(25 + i, 1 + j);
                        Console.Write('#');
                    }
                    else if (j > 24)
                    {
                        Console.Write('#');
                    }
                }
            }
        }

        public void DrawGround()
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.SetCursorPosition(28, 25);
            string floor = new string('_',23);
            Console.Write(floor);
            Console.ForegroundColor = ConsoleColor.White;

            Task.Run(Counter);
        }

        
        public void DrawPlayer()
        {
            Console.SetCursorPosition(PPx, PPy);
            Console.Write('0');


        }

        public bool counterstop = false;
        public int counter = 0;
        public async Task Counter()
        {
            while (!counterstop)
            {
                await Task.Delay(1000);
                ++counter;
            }
        }

        public void Dispose()
        {
        }
    }
}