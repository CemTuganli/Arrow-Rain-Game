﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowRain
{
    public static class Gallons
    {
        static readonly Globals _globalLock = Globals.LockObject;
        static readonly Arrows _arr = Arrows.Arr;

        public static byte _gallonPosX;
        public static byte _gallonPosY;

        public static readonly Random rnd = new Random();

        private static readonly byte[,] _gallonPos = new byte[14,14];
        public static byte[,] GallonPos
        {
            get { return _gallonPos; }
        }

        private static byte i = 0;
        public static void CreateDrawGallons()
        {
            while (i < 14)
            {
                lock (_globalLock)
                {
                    _gallonPosX = Convert.ToByte(rnd.Next(29, 50));
                    _gallonPosY = Convert.ToByte(rnd.Next(5, 23));

                    _gallonPos[i,0] = _gallonPosX;
                    _gallonPos[0,i] = _gallonPosY;

                    Console.SetCursorPosition(_gallonPosX, _gallonPosY);

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write('o');
                    Console.ForegroundColor = ConsoleColor.White;
                    ++i;
                }
            }
        }

        public static void RefreshGallonsForArrow1()
        {
            for (int i = 0; i < _gallonPos.GetLength(0); i++)
            {
                if ((_arr._apx1 == _gallonPos[i, 0] && _arr._apy1 - 1 == _gallonPos[0, i]) /*|| (_arr._apx2 == _gallonPos[i, 0] && _arr._apy2 - 1 == _gallonPos[0, i]) || (_arr._apx3 == _gallonPos[i, 0] && _arr._apy3 - 1 == _gallonPos[0, i]) || (_arr._apx4 - 1 == _gallonPos[i, 0] && _arr._apy4 - 1 == _gallonPos[0, i])*/)
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(_gallonPos[i, 0], _gallonPos[0, i]);

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write('o');
                        Console.ForegroundColor = ConsoleColor.White; 
                    }

                } 
            }
        }

        public static void RefreshGallonsForArrow2()
        {
            for (int i = 0; i < _gallonPos.GetLength(0); i++)
            {
                if (_arr._apx2 == _gallonPos[i, 0] && _arr._apy2 - 1 == _gallonPos[0, i])
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(_gallonPos[i, 0], _gallonPos[0, i]);

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write('o');
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                }
            }
        }
        public static void RefreshGallonsForArrow3()
        {
            for (int i = 0; i < _gallonPos.GetLength(0); i++)
            {
                if (_arr._apx3 == _gallonPos[i, 0] && _arr._apy3 - 1 == _gallonPos[0, i])
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(_gallonPos[i, 0], _gallonPos[0, i]);

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write('o');
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                }
            }
        }

        public static void RefreshGallonsForArrow4()
        {
            for (int i = 0; i < _gallonPos.GetLength(0); i++)
            {
                if (_arr._apx4 == _gallonPos[i, 0] && _arr._apy4 - 1 == _gallonPos[0, i])
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(_gallonPos[i, 0], _gallonPos[0, i]);

                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write('o');
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                }
            }
        }

    }
}
