﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class FireBullets : IDisposable
    {
        static readonly DrawMap _dm = DrawMap.Dm;
        static readonly Globals _globalLock = Globals.LockObject;
        static readonly Controller _ctrl = Controller.Ctrl;
        static readonly Arrows _arr = Arrows.Arr;
        static readonly Stats _st = Stats.St;


        #region Singleton
        private static Lazy<FireBullets> _fire;
        public static FireBullets Fire
        {
            get
            {
                if (_fire == null)
                {
                    _fire = new Lazy<FireBullets>(() => new FireBullets());
                }
                return _fire.Value;
            }
        }
        public FireBullets() { }
        #endregion

        //coordinatları dizi tutmaya gerek kalmadı
        public byte bulletXCoord = 0;
        public byte bulletYCoord = 0;

        public byte arrow1bodypartAmount = 3;
        public byte arrow2bodypartAmount = 3;

        public byte arrow3bodypartAmount = 3;
        public byte arrow4bodypartAmount = 3;

        private sbyte ammo = 7;
        private readonly string FullAmmoMessage = "Ammo:" + " 7 " + " - - - - - - - ";

        private string _notEnoughAmmoMessage = "";
        public string NotEnoughAmmoMessage
        {
            get { return _notEnoughAmmoMessage; }
            set { _notEnoughAmmoMessage = value; }
        }

        public void ShowRemainingBullets()
        {
            Console.SetCursorPosition(25, 29);
            Console.Write(FullAmmoMessage);
            switch (ammo)
            {
                case 7:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 7 " + " - - - - - - - ");
                    }
                    break;
                case 6:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 6 " + " - - - - - - ");
                    }
                    break;
                case 5:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 5 " + " - - - - - ");
                    }
                    break;
                case 4:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 4 " + " - - - - ");
                    }
                    break;
                case 3:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 3 " + " - - - ");
                    }
                    break;
                case 2:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 2 " + " - - ");
                    }
                    break;
                case 1:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 1 " + " - ");
                    }
                    break;
                case 0:
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(25, 29);
                        string space = new string(' ', FullAmmoMessage.Length);
                        Console.Write(space);
                        Console.SetCursorPosition(25, 29);
                        Console.Write("Ammo:" + " 0 ");
                    }
                    break;
                default:
                    break;
            }
        }

        public async Task FireMoveBullets()
        {
            if (_ctrl.C % 2 == 0)
            {
                lock (_globalLock)
                {
                    Console.SetCursorPosition(_dm.PPx, _dm.PPy);
                    Console.Write('0');
                }

                byte x = _dm.PPx;
                byte y = _dm.PPy;

                byte bulletY = 0;


                --ammo;

                if (ammo == 0)
                {
                    ShowRemainingBullets();
                    _ = Task.Run(FillAllBulletsTimer);
                    await Task.Run(() => MoveLastBullet(x, y, bulletY));
                }
                else if (ammo > 0)
                {
                    ShowRemainingBullets();
                    while (!_ctrl.restart)
                    {
                        if (_ctrl.C % 2 == 0)
                        {
                            lock (_globalLock)
                            {
                                Console.ForegroundColor = ConsoleColor.Blue;
                                Console.SetCursorPosition(x, y - 1);
                                bulletY = Convert.ToByte(y - 1);

                                Console.Write('\'');
                                Console.ForegroundColor = ConsoleColor.White;

                                bulletXCoord = x;

                                bulletYCoord = bulletY;

                                for (int i = 0; i < Gallons.GallonPos.GetLength(0); i++)
                                {
                                    if (bulletXCoord == Gallons.GallonPos[i, 0] && bulletYCoord == Gallons.GallonPos[0, i])
                                    {
                                        lock (_globalLock)
                                        {
                                            Console.SetCursorPosition(x, bulletYCoord);
                                            Console.Write(' ');
                                            Gallons.GallonPos[i, 0] = 0;
                                            Gallons.GallonPos[0, i] = 0;
                                            ++_st.Score;
                                            _st.DrawUpdateStats();
                                            if (_st.Score != 0 && _st.Score % 7 == 0)
                                            {
                                                for (int k = 0; k < 14; k++)
                                                {
                                                    lock (_globalLock)
                                                    {
                                                        if (Gallons.GallonPos[k, 0] == 0 && Gallons.GallonPos[0, k] == 0)
                                                        {
                                                            Gallons._gallonPosX = Convert.ToByte(Gallons.rnd.Next(35, 50));
                                                            Gallons._gallonPosY = Convert.ToByte(Gallons.rnd.Next(5, 23));

                                                            Gallons.GallonPos[k, 0] = Gallons._gallonPosX;
                                                            Gallons.GallonPos[0, k] = Gallons._gallonPosY;

                                                        }
                                                    }
                                                }
                                                for (int k = 0; k < 14; k++)
                                                {
                                                    lock (_globalLock)
                                                    {
                                                        Console.SetCursorPosition(Gallons.GallonPos[k, 0], Gallons.GallonPos[0, k]);

                                                        Console.ForegroundColor = ConsoleColor.Yellow;
                                                        Console.Write('o');
                                                        Console.ForegroundColor = ConsoleColor.White;
                                                    }
                                                }
                                            }
                                        }
                                        return;
                                    }
                                }

                                if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 + 1 || bulletYCoord == _arr._apy1 + 2) && arrow1bodypartAmount == 3)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow1bodypartAmount = 2;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 + 1 || bulletYCoord == _arr._apy2 + 2) && arrow2bodypartAmount == 3)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow2bodypartAmount = 2;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 + 1 || bulletYCoord == _arr._apy3 + 2) && arrow3bodypartAmount == 3)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow3bodypartAmount = 2;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 + 1 || bulletYCoord == _arr._apy4 + 2) && arrow4bodypartAmount == 3)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow4bodypartAmount = 2;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 || bulletYCoord == _arr._apy1 + 1) && arrow1bodypartAmount == 2)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow1bodypartAmount = 1;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 || bulletYCoord == _arr._apy2 + 1) && arrow2bodypartAmount == 2)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow2bodypartAmount = 1;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 || bulletYCoord == _arr._apy3 + 1) && arrow3bodypartAmount == 2)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow3bodypartAmount = 1;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 || bulletYCoord == _arr._apy4 + 1) && arrow4bodypartAmount == 2)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        arrow4bodypartAmount = 1;

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 - 1 || bulletYCoord == _arr._apy1) && arrow1bodypartAmount == 1)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        _arr._apx1 = Convert.ToByte(_arr.rnd.Next(30, 35));
                                        _arr._apy1 = Convert.ToByte(_arr.rnd.Next(3, 5));

                                        arrow1bodypartAmount = 3;

                                        ++_st.ArrowsDestroyed;
                                        _st.DrawUpdateStats();

                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 - 1 || bulletYCoord == _arr._apy2) && arrow2bodypartAmount == 1)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        _arr._apx2 = Convert.ToByte(_arr.rnd.Next(35, 40));
                                        _arr._apy2 = Convert.ToByte(_arr.rnd.Next(3, 5));

                                        arrow2bodypartAmount = 3;

                                        ++_st.ArrowsDestroyed;
                                        _st.DrawUpdateStats();
                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 - 1 || bulletYCoord == _arr._apy3) && arrow3bodypartAmount == 1)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        _arr._apx3 = Convert.ToByte(_arr.rnd.Next(41, 45));
                                        _arr._apy3 = Convert.ToByte(_arr.rnd.Next(3, 5));

                                        arrow3bodypartAmount = 3;

                                        ++_st.ArrowsDestroyed;
                                        _st.DrawUpdateStats();
                                    }
                                    return;
                                }
                                else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 - 1 || bulletYCoord == _arr._apy4) && arrow4bodypartAmount == 1)
                                {
                                    lock (_globalLock)
                                    {
                                        Console.SetCursorPosition(x, bulletYCoord);
                                        Console.Write(' ');

                                        _arr._apx4 = Convert.ToByte(_arr.rnd.Next(45, 50));
                                        _arr._apy4 = Convert.ToByte(_arr.rnd.Next(3, 5));

                                        arrow4bodypartAmount = 3;

                                        ++_st.ArrowsDestroyed;
                                        _st.DrawUpdateStats();
                                    }
                                    return;
                                }

                            }

                            await Task.Delay(150);

                            lock (_globalLock)
                            {
                                Console.SetCursorPosition(x, y - 1);
                                Console.Write(' ');
                                --y;

                            }

                            if (bulletY <= 3)
                            {
                                lock (_globalLock)
                                {
                                    Console.SetCursorPosition(x, bulletYCoord);
                                    Console.Write(' ');
                                }

                                return;
                            }
                        }
                    }
                }
                else
                {
                    ammo = 0;
                    if (ammo == 0)
                    {
                        AmmoWarning();
                    }

                }
            }


        }
        public async Task MoveLastBullet(byte x, byte y, byte bulletY)
        {
            while (true)
            {
                lock (_globalLock)
                {
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.SetCursorPosition(x, y - 1);
                    bulletY = Convert.ToByte(y - 1);

                    Console.Write('\'');
                    Console.ForegroundColor = ConsoleColor.White;

                    bulletXCoord = x;

                    bulletYCoord = bulletY;

                    for (int i = 0; i < Gallons.GallonPos.GetLength(0); i++)
                    {
                        if (bulletXCoord == Gallons.GallonPos[i, 0] && bulletYCoord == Gallons.GallonPos[0, i])
                        {
                            lock (_globalLock)
                            {
                                Console.SetCursorPosition(x, bulletYCoord);
                                Console.Write(' ');
                                Gallons.GallonPos[i, 0] = 0;
                                Gallons.GallonPos[0, i] = 0;
                                ++_st.Score;
                                _st.DrawUpdateStats();
                                if (_st.Score != 0 && _st.Score % 5 == 0)
                                {
                                    for (int k = 0; k < 10; k++)
                                    {
                                        lock (_globalLock)
                                        {
                                            if (Gallons.GallonPos[k, 0] == 0 && Gallons.GallonPos[0, k] == 0)
                                            {
                                                Gallons._gallonPosX = Convert.ToByte(Gallons.rnd.Next(35, 50));
                                                Gallons._gallonPosY = Convert.ToByte(Gallons.rnd.Next(5, 23));

                                                Gallons.GallonPos[k, 0] = Gallons._gallonPosX;
                                                Gallons.GallonPos[0, k] = Gallons._gallonPosY;

                                            }
                                        }
                                    }
                                    for (int k = 0; k < 19; k++)
                                    {
                                        lock (_globalLock)
                                        {
                                            Console.SetCursorPosition(Gallons.GallonPos[k, 0], Gallons.GallonPos[0, k]);

                                            Console.ForegroundColor = ConsoleColor.Yellow;
                                            Console.Write('o');
                                            Console.ForegroundColor = ConsoleColor.White;
                                        }
                                    }
                                }
                            }
                            return;
                        }
                    }

                    if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 + 1 || bulletYCoord == _arr._apy1 + 2) && arrow1bodypartAmount == 3)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow1bodypartAmount = 2;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 + 1 || bulletYCoord == _arr._apy2 + 2) && arrow2bodypartAmount == 3)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow2bodypartAmount = 2;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 + 1 || bulletYCoord == _arr._apy3 + 2) && arrow3bodypartAmount == 3)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow3bodypartAmount = 2;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 + 1 || bulletYCoord == _arr._apy4 + 2) && arrow4bodypartAmount == 3)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow4bodypartAmount = 2;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 || bulletYCoord == _arr._apy1 + 1) && arrow1bodypartAmount == 2)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow1bodypartAmount = 1;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 || bulletYCoord == _arr._apy2 + 1) && arrow2bodypartAmount == 2)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow2bodypartAmount = 1;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 || bulletYCoord == _arr._apy3 + 1) && arrow3bodypartAmount == 2)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow3bodypartAmount = 1;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 || bulletYCoord == _arr._apy4 + 1) && arrow4bodypartAmount == 2)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            arrow4bodypartAmount = 1;

                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx1 && (bulletYCoord == _arr._apy1 - 1 || bulletYCoord == _arr._apy1) && arrow1bodypartAmount == 1)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            _arr._apx1 = Convert.ToByte(_arr.rnd.Next(30, 35));
                            _arr._apy1 = Convert.ToByte(_arr.rnd.Next(3, 5));

                            arrow1bodypartAmount = 3;
                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx2 && (bulletYCoord == _arr._apy2 - 1 || bulletYCoord == _arr._apy2) && arrow2bodypartAmount == 1)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            _arr._apx2 = Convert.ToByte(_arr.rnd.Next(35, 40));
                            _arr._apy2 = Convert.ToByte(_arr.rnd.Next(3, 5));

                            arrow2bodypartAmount = 3;
                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx3 && (bulletYCoord == _arr._apy3 - 1 || bulletYCoord == _arr._apy3) && arrow3bodypartAmount == 1)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            _arr._apx3 = Convert.ToByte(_arr.rnd.Next(41, 45));
                            _arr._apy3 = Convert.ToByte(_arr.rnd.Next(3, 5));

                            arrow3bodypartAmount = 3;
                        }
                        return;
                    }
                    else if (bulletXCoord == _arr._apx4 && (bulletYCoord == _arr._apy4 - 1 || bulletYCoord == _arr._apy4) && arrow4bodypartAmount == 1)
                    {
                        lock (_globalLock)
                        {
                            Console.SetCursorPosition(x, bulletYCoord);
                            Console.Write(' ');

                            _arr._apx4 = Convert.ToByte(_arr.rnd.Next(45, 50));
                            _arr._apy4 = Convert.ToByte(_arr.rnd.Next(3, 5));

                            arrow4bodypartAmount = 3;
                        }
                        return;
                    }

                }

                await Task.Delay(150);

                lock (_globalLock)
                {
                    Console.SetCursorPosition(x, y - 1);
                    Console.Write(' ');
                    --y;

                }

                if (bulletY <= 3)
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(x, bulletYCoord);
                        Console.Write(' ');
                    }

                    return;
                }
            }
        }

        public void EraseAmmoWarning()
        {
            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(55, 27);
                string space2 = new string(' ', NotEnoughAmmoMessage.Length);
                Console.Write(space2);
                NotEnoughAmmoMessage = "";
            }
        }

        public void FillAllBulletsTimer()
        {
            AmmoCooldown();
            lock (_globalLock)
            {
                Console.SetCursorPosition(25, 29);
                string space = new string(' ', FullAmmoMessage.Length);
                Console.Write(space);
                Console.SetCursorPosition(25, 29);
                Console.Write(FullAmmoMessage);
                ammo = 7;
                EraseAmmoWarning();
            }

        }

        private void AmmoCooldown()
        {

            sbyte i = 5;
            string ammocooldownmessage = "Ammo CoolDown: ";
            while (i > -1)
            {
                lock (_globalLock)
                {
                    Console.SetCursorPosition(28 + FullAmmoMessage.Length, 29);
                    Console.Write(ammocooldownmessage + i);
                }

                Task.Delay(1000).Wait();

                if (i == 0)
                {
                    lock (_globalLock)
                    {
                        Console.SetCursorPosition(28 + FullAmmoMessage.Length, 29);
                        string space = new string(' ', ammocooldownmessage.Length + 1);
                        Console.Write(space);
                    }
                }
                --i;

            }
        }

        private void AmmoWarning()
        {
            NotEnoughAmmoMessage = "Not Enough Ammo!";

            lock (_globalLock)
            {
                Console.SetCursorPosition(55, 27);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(NotEnoughAmmoMessage);
            }

            Task.Delay(3000).Wait();

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(55, 27);
                string space2 = new string(' ', NotEnoughAmmoMessage.Length);
                Console.Write(space2);
                NotEnoughAmmoMessage = "";
            }
        }

        public void Dispose()
        {
        }
    }
}

