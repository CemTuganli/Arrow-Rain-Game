﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class Program : IDisposable
    {
        static readonly DrawMap _dm = DrawMap.Dm;
        static readonly Controller _ctrl = Controller.Ctrl;
        static readonly Arrows _arr = Arrows.Arr;
        static readonly FireBullets _fire = FireBullets.Fire;
        static readonly Stats _st = Stats.St;
        static readonly Globals _globalLock = Globals.LockObject;

        #region SINGLETON
        private static Lazy<Program> _pr;
        public static Program Pr
        {
            get
            {
                if (_pr == null)
                {
                    _pr = new Lazy<Program>(() => new Program());
                }
                return _pr.Value;
            }
        }

        #endregion


        private static readonly byte level = 1;
        public byte x1, y1;

        static async Task Main(string[] args)
        {
            
            Console.CursorVisible = true;
            if (level == 1)
            {
                await Pr.Opening(Pr.x1, Pr.y1);

            }
            else if (level == 2)
            {
                _dm.DrawPlayer();
                _dm.DrawGameMap();
                _dm.DrawGround();
                _fire.ShowRemainingBullets();

                _ = Task.Run(ManageControllerTask);
                await Task.Run(ManageArrowsLevel1);
            }
        }

        public static async Task ManageArrowsLevel1()
        {
            _arr.CreateArrows();
            _ = Task.Run(_arr.MoveDrawArrow1);
            _ = Task.Run(_arr.MoveDrawArrow2);
            _ = Task.Run(_arr.MoveDrawArrow3);
            await Task.Run(_arr.MoveDrawArrow4);
        }

        public static void ManageControllerTask()
        {
            while (true)
            {
                _ = _ctrl.ManageController();
            }
        }

        public bool okay = false;
        public async Task Opening(byte x, byte y)
        {
            Header(out x1, out y1);
            Console.ForegroundColor = ConsoleColor.Gray;
            while (true)
            {
                Pr.LoginPlayer();
                if (Pr.okay == true)
                {
                    Console.CursorVisible = false;
                    await Pr.Options(x1, y1);
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (ConsoleKey.D1 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        _ctrl.C = 0;

                        _dm.DrawPlayer();
                        _dm.DrawGameMap();
                        _dm.DrawGround();
                        Gallons.CreateDrawGallons();
                        _st.DrawUpdateStats();
                        _fire.ShowRemainingBullets();

                        _ = Task.Run(ManageControllerTask);
                        await Task.Run(ManageArrowsLevel1);
                    }
                    else if (ConsoleKey.D2 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowControllers();

                    }
                    else if (ConsoleKey.D3 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowIstatistics(x1, y1);
                    }
                    break;
                }
            }
        }

        private void Header(out byte x1, out byte y1)
        {
            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                string message1 = "Welcome To ARROW RAIN!";
                string message2 = "by Coherent Games";

                byte width = Convert.ToByte(Console.WindowWidth);
                byte height = Convert.ToByte(Console.WindowHeight);
                x1 = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(message1.Length)) / 2));
                y1 = Convert.ToByte(Convert.ToByte(height) / 2);
                Console.SetCursorPosition(x1 - 1, y1 - 4);
                Console.WriteLine(message1);
                Console.SetCursorPosition(x1 + 1, y1 - 2);
                Console.WriteLine(message2);
                Console.ForegroundColor = ConsoleColor.White;

            }
        }

        byte height;
        byte x;
        public async Task ShowIstatistics(byte x1, byte y1)
        {
            Console.SetCursorPosition(70, 2);
            Console.ForegroundColor = ConsoleColor.DarkRed;
            Console.Write("Go to Main Menu: B");
            Console.ForegroundColor = ConsoleColor.White;

            string messageStatistics = "STATISTICS";
            byte width = Convert.ToByte(Console.WindowWidth);
            height = 1;
            x = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(messageStatistics.Length)) / 2));
            Console.SetCursorPosition(x - 1, height);
            Console.WriteLine(messageStatistics);

            string connectionString = "Data Source=.;Initial Catalog=ArrowRainDB;Integrated Security=True;";
            try
            {
                // Set up a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Check if the connection to the database can be opened
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Set up a command to execute against the database
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = connection;

                    // Check if player name already exists in the database
                    cmd.CommandText = "SELECT PlayerID, PlayerName, DateCreated, Score, ArrowsDestroyed, TimePlayedInSeconds FROM PlayerLogin";
                    SqlDataReader dr = cmd.ExecuteReader();


                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            Console.WriteLine();
                            Console.WriteLine();
                            Console.WriteLine(dr["PlayerName"] + ",  " + dr["DateCreated"] + " - LoginDate,  " + dr["Score"] + " - Score,  " + dr["ArrowsDestroyed"] + " - ArrowsDestroyed,  " + dr["TimePlayedInSeconds"] + " - TimePlayedInSeconds");
                        }
                    }
                    else
                    {
                        Console.Write("No Rows Have Been Found In Your Database!");
                    }

                    dr.Close();
                    connection.Close();
                }
            }
            catch (SqlException ex)
            {
                // Display an error message to the user
                Console.WriteLine("Error adding player: " + ex.Message);
            }
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                await Pr.Options(x1, y1);

            }
        }

        public string enternamemessage = "Enter player name: ";
        public string playerName;
        public int PlayerID;

        public void LoginPlayer()
        {

            string connectionString = "Data Source=.;Initial Catalog=ArrowRainDB;Integrated Security=True;";

            Console.SetCursorPosition(0, 15);
            Console.Write(Pr.enternamemessage);

            Pr.playerName = Console.ReadLine();

            // Check if the player name is empty or null
            if (string.IsNullOrWhiteSpace(Pr.playerName))
            {
                WriteEraseCanNOTbeEmptyMessage();
                return;
            }

            // Check if the player name is too long
            if (Pr.playerName.Length > 50)
            {
                WriteErase50CharactersMessage();
                return;
            }

            try
            {
                // Set up a connection to the database
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Check if the connection to the database can be opened
                    if (connection.State == ConnectionState.Closed)
                    {
                        connection.Open();
                    }

                    // Set up a command to execute against the database
                    using (SqlCommand command = new SqlCommand())
                    {

                        command.Connection = connection;

                        // Check if player name already exists in the database
                        command.CommandText = "SELECT COUNT(*) FROM PlayerLogin WHERE PlayerName = @PlayerName";
                        command.Parameters.AddWithValue("@PlayerName", Pr.playerName);


                        int count = Convert.ToInt32(command.ExecuteScalar());
                        if (count > 0)
                        {
                            EraseAlreadyExistsMessage();
                            return;
                        }

                        // Insert new player into database
                        command.CommandText = "INSERT INTO PlayerLogin (PlayerName) VALUES (@PlayerName)";

                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            // Create a new SqlCommand object to execute your SQL query
                            using (SqlCommand cmd = new SqlCommand("SELECT @@IDENTITY", connection))
                            {
                                // Execute the query and retrieve the current player ID
                                PlayerID = Convert.ToInt32(cmd.ExecuteScalar());

                                PlayerAddedMessageWriteErase();
                                Pr.okay = true;
                            }
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                // Display an error message to the user
                Console.WriteLine("Error adding player: " + ex.Message);
            }

        }

        public void PlayerAddedMessageWriteErase()
        {
            string playeraddedMessage = "Player added.";
            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.WriteLine(playeraddedMessage);
            }
            Task.Delay(2000).Wait();
            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', playeraddedMessage.Length);
                Console.Write(space);
                Console.ForegroundColor = ConsoleColor.White;
            }
        }

        public void WriteEraseCanNOTbeEmptyMessage()
        {
            string messageCanNotBeEmpty = "Player name cannot be empty.";

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.Write(messageCanNotBeEmpty);
            }

            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', messageCanNotBeEmpty.Length);
                Console.Write(space);
                Console.ForegroundColor = ConsoleColor.White;

            }


        }

        public void WriteErase50CharactersMessage()
        {


            string message50Characters = "Player name is too long. Maximum length is 50 characters.";

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.WriteLine(message50Characters);
            }

            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', message50Characters.Length);
                Console.Write(space);

                Console.SetCursorPosition(Pr.enternamemessage.Length, 15);
                string spaceName = new string(' ', Pr.playerName.Length);
                Console.Write(spaceName);
            }


        }

        public void EraseAlreadyExistsMessage()
        {
            Program pr = new Program();

            string messageAlreadyExists = "Player name already exists. Use Another Name!";
            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.SetCursorPosition(0, 16);
                Console.WriteLine(messageAlreadyExists);
            }
            Task.Delay(1500).Wait();

            lock (_globalLock)
            {
                Console.ForegroundColor = ConsoleColor.White;
                Console.SetCursorPosition(0, 16);
                string space = new string(' ', messageAlreadyExists.Length);
                Console.Write(space);
            }

            Console.SetCursorPosition(pr.enternamemessage.Length, 15);
            string spaceName = new string(' ', pr.enternamemessage.Length);
            Console.Write(spaceName);
        }

        public async Task Options(byte x, byte y)
        {
            Header(out x, out y);

            string message3 = "PRESS";
            string message4 = "1 - Start ARROW RAIN!";
            string message5 = "2 - Controlls";
            string message6 = "3 - Statistics";

            lock (_globalLock)
            {
                Console.SetCursorPosition(x + 1, y);
                Console.WriteLine(message3);
                Console.SetCursorPosition(x + 1, y + 1);
                Console.WriteLine(message4);
                Console.SetCursorPosition(x + 1, y + 2);
                Console.WriteLine(message5);
                Console.SetCursorPosition(x + 1, y + 3);
                Console.WriteLine(message6);
            }

            while (true)
            {
                if (Pr.okay == true)
                {
                    Console.CursorVisible = false;
                    ConsoleKeyInfo key = Console.ReadKey(true);
                    if (ConsoleKey.D1 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        _ctrl.C = 0;

                        _dm.DrawPlayer();
                        _dm.DrawGameMap();
                        _dm.DrawGround();
                        Gallons.CreateDrawGallons();
                        _st.DrawUpdateStats();
                        _fire.ShowRemainingBullets();


                        _ = Task.Run(ManageControllerTask);
                        //_ = Task.Run(() => GoBack1(x, y));
                        await Task.Run(ManageArrowsLevel1);

                    }
                    else if (ConsoleKey.D2 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();
                        await ShowControllers();


                    }
                    else if (ConsoleKey.D3 == key.Key)
                    {
                        Console.CursorVisible = false;

                        Console.Clear();

                        await ShowIstatistics(x1, y1);
                    }
                    break;
                }
            }
        }

        //private void GoBack1(byte x, byte y)
        //{
        //    Console.SetCursorPosition(70, 4);
        //    Console.ForegroundColor = ConsoleColor.DarkGray;
        //    Console.WriteLine("Go to Main Menu: B");
        //    Console.ForegroundColor = ConsoleColor.White;

        //menu:
        //    ConsoleKeyInfo key = Console.ReadKey(true);
        //    if (key.Key == ConsoleKey.B)
        //    {
        //        Console.Clear();
        //        _st.Health = 5;
        //        _st.Score = 0;
        //        _st.ArrowsDestroyed = 0;
        //        _ctrl.C = 0;
        //        _=Options(x, y);

        //    }
        //    else
        //    {
        //        goto menu;
        //    }
        //}

        public async Task ShowControllers()
        {
            string messageStatistics = "CONTROLLERS";
            byte width = Convert.ToByte(Console.WindowWidth);
            height = 1;
            x = Convert.ToByte(Convert.ToByte((width - Convert.ToByte(messageStatistics.Length)) / 2));
            Console.SetCursorPosition(x - 1, height);
            Console.WriteLine(messageStatistics);

            Console.SetCursorPosition(70, 2);
            Console.WriteLine("Go to Main Menu: B");

            Console.WriteLine("Press 'A' to Move Left \n");
            Console.WriteLine("Press 'D' to Move Right \n");
            Console.WriteLine("Press 'F' to Fire \n");
            Console.WriteLine("Press 'P' to Pause Game \n");

        menu:
            ConsoleKeyInfo key = Console.ReadKey(true);
            if (key.Key == ConsoleKey.B)
            {
                Console.Clear();
                await Pr.Options(x1, y1);

            }
            else
            {
                goto menu;
            }
        }

        public void Dispose()
        {

        }
    }
}
