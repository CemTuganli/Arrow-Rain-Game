﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace ArrowRain
{
    public class MovePlayer : IDisposable
    {
        static readonly DrawMap dm = DrawMap.Dm;
        static readonly Globals _globalLock = Globals.LockObject;
        static readonly Controller _ctrl = Controller.Ctrl;

        #region Singleton
        private static Lazy<MovePlayer> _mp;
        public static MovePlayer Mp
        {
            get
            {
                if (_mp == null)
                    _mp = new Lazy <MovePlayer>(() => new MovePlayer());
                return _mp.Value;
            }


        }
        private MovePlayer() { } 
        #endregion

        public void MovePlayerRight()
        {
            lock (_globalLock)
            {
                if (dm.PPx < 50 && _ctrl.C % 2 == 0)
                {
                    Console.SetCursorPosition(dm.PPx, dm.PPy);
                    Console.Write(' ');
                    Console.SetCursorPosition(++dm.PPx, dm.PPy);
                    Console.Write('0');  
                }
            }
        }
        public void MovePlayerLeft()
        {
            lock (_globalLock)
            {
                if (dm.PPx > 28 && _ctrl.C % 2 == 0)
                {
                    Console.SetCursorPosition(dm.PPx, dm.PPy);
                    Console.Write(' ');
                    Console.SetCursorPosition(--dm.PPx, dm.PPy);
                    Console.Write('0');  
                }
            }
        }

        public void Dispose()
        {
        }
    }
}
